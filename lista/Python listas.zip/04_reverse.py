#list.reverse()
#crear una lista

mi_lista = [10, 20, 30, 40]

#invertir el ORDEN de los elementos
mi_lista.reverse()

print(mi_lista)