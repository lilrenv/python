#crear una lista 

mi_lista = [10, 30, 40, 50]
mi_lista[-1] = 8

print(mi_lista)