#Renato Silva
#Sigo cansado el dia de hoy
#25/03/2025

peso_corporal = 60 #Peso corporal personal
altura = 1.70 #Altura personal
imc = (peso_corporal / altura** 2)
print(imc)