#Renato Silva
#En estos momentos estoy super cansado
#25/03/2025
fahrenheit = 62.6  # Temperatura en Fahrenheit de San Ramon
celsius = (fahrenheit - 32) / 1.8
print(celsius)
