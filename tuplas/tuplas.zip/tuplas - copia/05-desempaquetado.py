#desempaquetar la tupla
#entender como se asigna los valores de una tupla a variables

tupla = (10, 20, 30)
a, b, c, = tupla

print(a,b, c)