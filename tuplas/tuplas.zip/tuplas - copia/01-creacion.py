#creacion de tupla
#saber como definir una tupla utilizando parentesis ()

tupla = ("elementos1", "elementos2", "elementos3")

print(tupla)