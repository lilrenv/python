#concatenar tupla
#saber que las tuplas  pueden combinarse usando el operador +.

tupla1 = (1, 2)
tupla2 = (3, 4)
nueva_tupla = tupla1 + tupla2

print(nueva_tupla)