#longitud de una tupla (len)
#usar la funcion len() para determinar cuantos elementos tiene una tupla

tupla = (1, 2, 3, 4, 5)

print(len(tupla))