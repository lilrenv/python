#verificar la existencia de un elemento (in)
#saber usar el operador in para comprobar si un elemento esta presente en la tupla

tupla = ("python", "java", "C++")

print("java" in tupla)